package repository.file;

import domain.Friendship;
import domain.Tuple;
import domain.validators.Validator;

/**
 * Text file repository for friendships; one friendship per line,
 * with the format id1;id2
 */
public class FriendshipFileRepository extends AbstractFileRepository<Tuple<Long, Long>, Friendship> {

    /**
     * @param validator - the validation strategy for friendships
     * @param fileName  - the path of the text file
     */
    public FriendshipFileRepository(Validator<Friendship> validator, String fileName) {
        super(validator, fileName);
    }

    /**
     * @param line - a line with the format id1;id2
     * @return the friendship described by the line
     */
    @Override
    protected Friendship extractEntity(String line) {
        String[] fields = line.split(";", -1);
        Long id1 = Long.parseLong(fields[0]);
        Long id2 = Long.parseLong(fields[1]);
        return new Friendship(id1, id2);

    }

    /**
     * @param friendship - the friendship to be converted
     * @return the line id1;id2
     */
    @Override
    protected String createEntityAsString(Friendship friendship) {
        return friendship.getUserId1() + ";" + friendship.getUserId2();
    }
}
