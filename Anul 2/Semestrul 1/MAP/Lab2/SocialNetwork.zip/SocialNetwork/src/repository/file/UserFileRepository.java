package repository.file;

import domain.User;
import domain.validators.Validator;

/**
 * Text file repository for users; one user per line,
 * with the format id;firstName;lastName;email
 */
public class UserFileRepository extends AbstractFileRepository<Long, User> {

    /**
     * @param validator - the validation strategy for users
     * @param fileName  - the path of the text file
     */
    public UserFileRepository(Validator<User> validator, String fileName) {
        super(validator, fileName);
    }

    /**
     * @param line - a line with the format id;firstName;lastName;email
     * @return the user described by the line
     */
    @Override
    protected User extractEntity(String line) {
        String[] fields = line.split(";", -1);
        User user = new User(fields[1], fields[2], fields[3]);
        user.setId(Long.parseLong(fields[0]));
        return user;
    }

    /**
     * @param user - the user to be converted
     * @return the line id;firstName;lastName;email
     */
    @Override
    protected String createEntityAsString(User user) {
        return user.getId() + ";" + user.getFirstName() + ";" + user.getLastName() + ";" + user.getEmail();
    }
}