package repository.file;

import domain.Entity;
import domain.validators.Validator;
import repository.InMemoryRepository;

import java.io.*;

/**
 * Repository that keeps the entities in memory and in a text file (one entity per line).
 * Template Method: reading and writing the file are written here once;
 * subclasses only say how a line becomes an entity and back.
 *
 * @param <ID> - type E must have an attribute of type ID
 * @param <E>  - type of entities saved in repository
 */
public abstract class AbstractFileRepository<ID, E extends Entity<ID>> extends InMemoryRepository<ID, E> {

    private final String fileName;

    /**
     * @param validator - the validation strategy for the entities
     * @param fileName  - the path of the text file
     */
    public  AbstractFileRepository(Validator<E> validator, String fileName) {
        super(validator);
        this.fileName = fileName;

        loadData();
    }

    /**
     * @param line - a line of the file
     * @return the entity described by the line
     */
    protected abstract E extractEntity(String line);

    /**
     * @param entity - the entity to be converted
     * @return the line of text that describes the entity
     */
    protected abstract String createEntityAsString(E entity);

    private void loadData(){
        try(BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if(line.isBlank())
                    continue;
                E entity = extractEntity(line);
                super.save(entity);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found. Empty repository");
        } catch (IOException e) {
            throw new RuntimeException("Error while reading the file " + fileName, e);
        }
    }

    private void writeToFile(){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (E entity : findAll()) {
                writer.write(createEntityAsString(entity));
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Error while writing the file " + fileName, e);
        }
    }

    @Override
    public E save(E entity) {
        E result  = super.save(entity);
        if(result == null){
            writeToFile();
        }
        return result;
    }

    @Override
    public E delete(ID id) {
        E result = super.delete(id);
        if(result != null){
            writeToFile();
        }
        return result;
    }

    @Override
    public E update(E entity) {
        E result = super.update(entity);
        if(result == null){
            writeToFile();
        }
        return result;
    }
}
