package domain;

/**
 * User of the social network, identified by an id of type Long
 */
public class User extends Entity<Long> {

    private String firstName;
    private String lastName;
    private String email;

    /**
     * @param firstName - prenume
     * @param lastName - nume
     * @param email - adresa email
     */

    public User(String firstName, String lastName,  String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName =lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return getId() + ", " + firstName + ", " + lastName +  ", " + "(" + email + ")";
    }
}
