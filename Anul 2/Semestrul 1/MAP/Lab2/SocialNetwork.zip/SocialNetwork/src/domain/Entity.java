package domain;

import java.util.Objects;

/**
 * Base class for all entities that have an identifier
 *
 * @param <ID> - type of the entity identifier
 */
public class Entity<ID> {

    private ID id;

    public ID getId() {
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Entity<?>)) return false;

        Entity<?> entity = (Entity<?>) o;
        return Objects.equals(id, entity.id);

    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}