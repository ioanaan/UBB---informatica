package domain;

/**
 * Friendship between two users. The id is the pair of user ids,
 * always ordered with the smaller id first, so (1, 7) and (7, 1)
 * represent the same friendship.
 */
public class Friendship extends Entity<Tuple<Long, Long>> {

    /**
     * creates the friendship and sets its id to (smaller id, bigger id)
     *
     * @param id1 - the id of one user
     * @param id2 - the id of the other user
     */
    public Friendship(Long id1, Long id2) {
        Long smaller = Math.min(id1,id2);
        Long bigger = Math.max(id1,id2);
        setId(new Tuple<>(smaller, bigger));

    }

    public Long getUserId1() {
        return getId().getE1();
    }

    public Long getUserId2() {
        return getId().getE2();
    }

    @Override
    public String toString() {
        return getUserId1() + " " + getUserId2();
    }

}
