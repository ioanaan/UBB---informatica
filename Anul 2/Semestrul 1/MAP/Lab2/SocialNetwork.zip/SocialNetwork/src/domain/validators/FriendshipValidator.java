package domain.validators;

import domain.Friendship;

import java.util.Objects;

/**
 * Validation strategy for Friendship entities.
 * A friendship is valid if both user ids are positive and different.
 * The existence of the users is checked by the service, not here.
 */
public class FriendshipValidator implements Validator<Friendship> {

    /**
     * @param entity - the friendship to be validated
     * @throws ValidationException if the friendship is null or not valid
     */
    @Override
    public void validate(Friendship entity) {
        if(entity == null)
            throw new ValidationException("Friendship cannot be null ");

        String errors = "";
        Long id1 = entity.getUserId1();
        Long id2 = entity.getUserId2();

        if(id1 == null || id1 <= 0)
            errors += "Invalid ID1 ";

        if(id2 == null || id2 <= 0)
            errors += "Invalid ID2 ";

        if(Objects.equals(id1, id2)) errors += "A user cannot be friend with himself ";

        if(!errors.isEmpty())
            throw new ValidationException(errors);

    }
}
