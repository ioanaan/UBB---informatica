package domain;

import java.util.Objects;

/**
 * Immutable pair of two values
 *
 * @param <E1> - type of the first value
 * @param <E2> - type of the second value
 */
public class Tuple<E1, E2> {

    private final E1 e1;
    private final E2 e2;

    public Tuple(E1 e1, E2 e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    public E1 getE1() {
        return e1;
    }

    public E2 getE2() {
        return e2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if(!(o instanceof Tuple<?, ?>)) return false;

        Tuple<?, ?> tuple = (Tuple<?, ?>) o;
        return Objects.equals(e1, tuple.e1) && Objects.equals(e2, tuple.e2);

    }

    @Override
    public int hashCode() {
        return Objects.hash(e1, e2);
    }
}
