import domain.Friendship;
import domain.Tuple;
import domain.User;
import domain.validators.FriendshipValidator;
import domain.validators.UserValidator;
import repository.Repository;
import repository.file.FriendshipFileRepository;
import repository.file.UserFileRepository;
import service.CommunityService;
import service.FriendshipService;
import service.UserService;
import ui.ConsoleUI;
import ui.UI;

/**
 * Entry point of the application.
 * Builds all the components (validators, repositories, services, UI) and starts the UI.
 */
public class Main {

    /**
     * Wires the layers together and starts the console UI.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {

        Repository<Long, User> userRepository =
                new UserFileRepository(new UserValidator(), "data/users.txt");
        Repository<Tuple<Long, Long>, Friendship> friendshipRepository =
                new FriendshipFileRepository(new FriendshipValidator(), "data/friendships.txt");

        UserService userService = new UserService(userRepository, friendshipRepository);
        FriendshipService friendshipService = new FriendshipService(friendshipRepository, userRepository);
        CommunityService communityService = new CommunityService(userRepository, friendshipRepository);

        UI ui = new ConsoleUI(userService, friendshipService, communityService);
        ui.run();
    }
}