package ui;

import domain.Friendship;
import domain.User;
import domain.validators.ValidationException;
import service.CommunityService;
import service.FriendshipService;
import service.UserService;
import service.exceptions.DuplicateEntityException;
import service.exceptions.EntityNotFoundException;

import java.util.List;
import java.util.Scanner;

/**
 * Console user interface.
 * Reads commands, calls the services and displays the results.
 * It is the only layer that catches exceptions and shows them as messages.
 */
public class ConsoleUI implements UI{

    private final UserService userService;
    private final FriendshipService friendshipService;
    private final CommunityService communityService;
    private final Scanner scanner = new Scanner(System.in);

    /**
     * Creates the console UI with the services it needs.
     *
     * @param userService       service for users
     * @param friendshipService service for friendships
     * @param communityService  service for communities
     */
    public ConsoleUI(UserService userService, FriendshipService friendshipService,
                     CommunityService communityService) {
        this.userService = userService;
        this.friendshipService = friendshipService;
        this.communityService = communityService;
    }

    /**
     * Starts the main loop: shows the menu and runs the chosen option
     * until the user chooses to exit (0).
     */
    @Override
    public void run() {
        while (true) {
            printMenu();
            String option = scanner.nextLine().trim();
            if (option.equals("0")) {
                System.out.println("Goodbye!");
                return;
            }
            try {
                switch (option) {
                    case "1" -> addUser();
                    case "2" -> removeUser();
                    case "3" -> addFriend();
                    case "4" -> removeFriend();
                    case "5" -> showUsers();
                    case "6" -> showFriendships();
                    case "7" -> showNumberOfCommunities();
                    case "8" -> showMostSociableCommunity();
                    default -> System.out.println("Invalid option.");
                }
            } catch (NumberFormatException e) {
                System.out.println("The id must be a number.");
            } catch (ValidationException e) {
                System.out.println("Invalid data: " + e.getMessage());
            } catch (EntityNotFoundException | DuplicateEntityException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    /** Prints the menu options. */
    private void printMenu() {
        System.out.println();
        System.out.println("1. Add user");
        System.out.println("2. Remove user");
        System.out.println("3. Add friend");
        System.out.println("4. Remove friend");
        System.out.println("5. Show users");
        System.out.println("6. Show friendships");
        System.out.println("7. Number of communities");
        System.out.println("8. Most sociable community");
        System.out.println("0. Exit");
        System.out.print("Option: ");
    }

    /** Prints the message and reads a line of text from the keyboard. */
    private String readString(String message) {
        System.out.print(message);
        return scanner.nextLine().trim();
    }

    /** Reads an id; throws NumberFormatException if the text is not a number. */
    private Long readLong(String message) {
        return Long.parseLong(readString(message));
    }

    /** Reads the user data and adds the user. */
    private void addUser() {
        Long id = readLong("Id: ");
        String firstName = readString("First name: ");
        String lastName = readString("Last name: ");
        String email = readString("Email: ");
        userService.addUser(id, firstName, lastName, email);
        System.out.println("User added.");
    }

    /** Reads an id and removes the user together with their friendships. */
    private void removeUser() {
        Long id = readLong("Id of the user to remove: ");
        userService.removeUser(id);
        System.out.println("User removed (together with their friendships).");
    }

    /** Reads two ids and creates a friendship between them. */
    private void addFriend() {
        Long id1 = readLong("Id of the first user: ");
        Long id2 = readLong("Id of the second user: ");
        friendshipService.addFriend(id1, id2);
        System.out.println("Friendship added.");
    }

    /** Reads two ids and removes the friendship between them. */
    private void removeFriend() {
        Long id1 = readLong("Id of the first user: ");
        Long id2 = readLong("Id of the second user: ");
        friendshipService.removeFriend(id1, id2);
        System.out.println("Friendship removed.");
    }

    /** Prints all users. */
    private void showUsers() {
        for (User user : userService.getAll()) {
            System.out.println(user);
        }
    }

    /** Prints all friendships. */
    private void showFriendships() {
        for (Friendship friendship : friendshipService.getAll()) {
            System.out.println(friendship);
        }
    }

    /** Prints the number of communities. */
    private void showNumberOfCommunities() {
        System.out.println("Number of communities: " + communityService.numberOfCommunities());
    }

    /** Prints the users from the most sociable community. */
    private void showMostSociableCommunity() {
        List<Long> community = communityService.mostSociableCommunity();
        if (community.isEmpty()) {
            System.out.println("There are no users.");
            return;
        }
        System.out.println("Most sociable community:");
        for (User user : userService.getAll()) {
            if (community.contains(user.getId())) {
                System.out.println(user);
            }
        }
    }
}