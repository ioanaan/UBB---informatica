package service.exceptions;

/**
 * Unchecked exception thrown by the service when the entity already exists
 */
public class DuplicateEntityException extends RuntimeException {

    /**
     * @param message - details about the existing entity (e.g. "user 7")
     */
    public DuplicateEntityException(String message) {
        super("Duplicate entity: " + message);
    }
}
