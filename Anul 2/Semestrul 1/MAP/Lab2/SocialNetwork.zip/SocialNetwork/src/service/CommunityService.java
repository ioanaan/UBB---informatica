package service;

import domain.Friendship;
import domain.Tuple;
import domain.User;
import repository.Repository;

import java.util.*;

/**
 * Service for the communities of the network (connected components of the friendship graph)
 */
public class CommunityService {

    private final Repository<Long, User> users;
    private final Repository<Tuple<Long, Long>, Friendship> friendships;

    /**
     * @param users - the repository of users (the vertices of the graph)
     * @param friendships - the repository of friendships (the edges of the graph)
     */
    public CommunityService(Repository<Long, User> users,
                            Repository<Tuple<Long, Long>, Friendship> friendships) {
        this.users = users;
        this.friendships = friendships;
    }

    /**
     * Construieste lista de adiacenta a grafului: pentru fiecare utilizator,
     * lista id-urilor prietenilor lui.
     * Fiecare utilizator apare ca cheie, chiar daca nu are prieteni (lista goala).
     * Fiecare prietenie este adaugata in ambele sensuri, deoarece graful este neorientat.
     *
     * @return map-ul id utilizator -> lista id-urilor prietenilor
     */
    private Map<Long, List<Long>> buildGraph() {
        Map<Long, List<Long>> graph = new HashMap<>();

        for (User user : users.findAll()) {
            graph.put(user.getId(), new ArrayList<>());
        }

        for (Friendship f : friendships.findAll()) {
            Long a = f.getUserId1();
            Long b = f.getUserId2();
            if(graph.containsKey(a) && graph.containsKey(b)) {
                graph.get(a).add(b);
                graph.get(b).add(a);
            }
        }

        return graph;
    }

    /**
     * Parcurgere in adancime (DFS) care aduna in {@code component} toti utilizatorii
     * la care se poate ajunge pornind din {@code node}.
     * Nodurile vizitate raman marcate, ca sa nu fie parcurse de doua ori.
     *
     * @param node - nodul curent
     * @param graph - lista de adiacenta
     * @param visited - multimea nodurilor deja vizitate
     * @param component - lista in care se aduna comunitatea curenta
     */
    private void dfs(Long node, Map<Long, List<Long>> graph, Set<Long> visited, List<Long> component) {
        visited.add(node);
        component.add(node);

        for (Long next: graph.get(node)) {
            if (!visited.contains(next)) {
                dfs(next, graph, visited, component);
            }
        }
    }

    /**
     * Determina toate comunitatile din retea (componentele conexe ale grafului).
     * Din fiecare utilizator inca nevizitat porneste un DFS, care gaseste o comunitate noua.
     *
     * @return lista comunitatilor; fiecare comunitate este o lista de id-uri de utilizatori
     */
    public List<List<Long>> getCommunities() {
        Map<Long, List<Long>> graph = buildGraph();
        Set<Long> visited = new HashSet<>();
        List<List<Long>> communities = new ArrayList<>();

        for (Long userId : graph.keySet()) {
            if (!visited.contains(userId)) {
                List<Long> component = new ArrayList<>();
                dfs(userId, graph, visited, component);
                communities.add(component);
            }
        }

        return communities;
    }

    /**
     * Determinates the number of communities of the network
     *
     * @return the number of connected components
     */
    public int numberOfCommunities() {
        return getCommunities().size();
    }

    /**
     * Calculeaza lungimea (numar de muchii) a celui mai lung drum fara noduri repetate
     * care porneste din {@code node}. Foloseste backtracking: la intoarcere nodul este
     * scos din {@code visited}, ca sa poata face parte si din alte drumuri.
     *
     * @param node    nodul de pornire
     * @param graph   lista de adiacenta
     * @param visited nodurile aflate pe drumul curent
     * @return lungimea celui mai lung drum care incepe din {@code node}
     */
    private int longestPathFrom(Long node, Map<Long, List<Long>> graph, Set<Long> visited) {
        visited.add(node);
        int best = 0;
        for (Long next : graph.get(node)) {
            if (!visited.contains(next)) {
                int length = 1 + longestPathFrom(next, graph, visited); // muchia node-next + restul
                if (length > best) {
                    best = length;
                }
            }
        }
        visited.remove(node);   // backtracking
        return best;
    }

    /**
     * Calculeaza cel mai lung drum dintr-o comunitate, incercand fiecare utilizator
     * din ea ca punct de pornire.
     *
     * @param community lista id-urilor din comunitate
     * @param graph     lista de adiacenta
     * @return lungimea celui mai lung drum din comunitate
     */
    private int longestPathInCommunity(List<Long> community, Map<Long, List<Long>> graph) {
        int best = 0;
        for (Long start : community) {
            int length = longestPathFrom(start, graph, new HashSet<>());
            if (length > best) {
                best = length;
            }
        }
        return best;
    }

    /**
     * Determina cea mai sociabila comunitate, adica comunitatea care contine
     * cel mai lung drum fara noduri repetate.
     *
     * @return lista id-urilor utilizatorilor din comunitate,
     *         sau o lista goala daca nu exista utilizatori
     */
    public List<Long> mostSociableCommunity() {
        Map<Long, List<Long>> graph = buildGraph();
        List<Long> bestCommunity = new ArrayList<>();
        int bestLength = -1;

        for (List<Long> community : getCommunities()) {
            int length = longestPathInCommunity(community, graph);
            if (length > bestLength) {
                bestLength = length;
                bestCommunity = community;
            }
        }
        return bestCommunity;
    }

}