package service;

import domain.Friendship;
import domain.Tuple;
import domain.User;
import repository.Repository;
import service.exceptions.DuplicateEntityException;
import service.exceptions.EntityNotFoundException;

import java.util.ArrayList;
import java.util.List;

/**
 * Service with the business rules for users
 */
public class UserService extends AbstractService<Long, User> {

    private final Repository<Tuple<Long, Long>, Friendship> friendships;

    /**
     * @param users - the repository of users
     * @param friendships - the repository of friendships (needed when a user is removed)
     */
    public UserService(Repository<Long, User> users,
                       Repository<Tuple<Long, Long>, Friendship> friendships) {
        super(users);
        this.friendships = friendships;
    }

    /**
     * Adds a user
     *
     * @param id - id of the user
     * @param firstName - the first name
     * @param lastName - the last name
     * @param email - the email
     * @throws domain.validators.ValidationException -> if the user data is not valid
     * @throws DuplicateEntityException -> if a user with the same id already exists
     */
    public void addUser(Long id, String firstName, String lastName, String email) {
        User user = new User(firstName, lastName, email);
        user.setId(id);

        User result = repository.save(user);
        if (result != null) {
            throw new DuplicateEntityException("User with id " + id);
        }
    }

    /**
     * Removes a user and all his friendships
     *
     * @param id - the id of the user to be removed
     * @throws EntityNotFoundException -> if there is no user with the given id
     */
    public void removeUser(Long id) {
        if (repository.findOne(id) == null) {
            throw new EntityNotFoundException("User with id: " + id);
        }

        List<Tuple<Long, Long>> toDelete = new ArrayList<>();
        for (Friendship f : friendships.findAll()) {
            if (f.getUserId1().equals(id) || f.getUserId2().equals(id)) {
                toDelete.add(f.getId());
            }
        }

        for (Tuple<Long, Long> fID : toDelete) {
            friendships.delete(fID);
        }

        repository.delete(id);
    }
}