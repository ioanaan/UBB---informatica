package service;

import domain.Friendship;
import domain.Tuple;
import domain.User;
import repository.Repository;
import service.exceptions.DuplicateEntityException;
import service.exceptions.EntityNotFoundException;

/**
 * Service with the business rules for friendships
 */
public class FriendshipService extends AbstractService<Tuple<Long, Long>, Friendship> {

    private final Repository<Long, User> users;

    /**
     * @param friendships - the repository of friendships
     * @param users - the repository of users (needed to check that users exist)
     */
    public FriendshipService(Repository<Tuple<Long, Long>, Friendship> friendships,
                             Repository<Long, User> users) {
        super(friendships);
        this.users = users;
    }

    /**
     * Adds a friendship between 2 users
     *
     * @param id1 - the id of the first user
     * @param id2 - the id of the second user
     * @throws EntityNotFoundException -> if one of the users does not exist
     * @throws domain.validators.ValidationException -> if the friendship is not valid
     * @throws DuplicateEntityException -> if the friendship already exists
     */
    public void addFriend(Long id1, Long id2) {
        if (users.findOne(id1) == null) {
            throw new EntityNotFoundException("User with id: " + id1);
        }
        if (users.findOne(id2) == null) {
            throw new EntityNotFoundException("User with id " + id2);
        }

        Friendship friendship = new Friendship(id1, id2);
        Friendship result = repository.save(friendship);
        if (result != null) {
            throw new DuplicateEntityException("Friendship: " + id1 + " - " + id2);
        }
    }

    /**
     * Removes the friendship between two users
     *
     * @param id1 - the id of the first user
     * @param id2 - the id of the second user
     * @throws EntityNotFoundException -> if the friendship does not exist
     */
    public void removeFriend(Long id1, Long id2) {
        Tuple<Long, Long> key = new Friendship(id1, id2).getId();

        Friendship result = repository.delete(key);
        if (result == null) {
            throw new EntityNotFoundException("Friendship " + id1 + " - " + id2);
        }
    }
}