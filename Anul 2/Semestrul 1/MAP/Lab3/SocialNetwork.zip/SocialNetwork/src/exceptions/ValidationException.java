package exceptions;

/**
 * Unchecked exception thrown by a validator when an entity is not valid.
 * It propagates through repository and service and is caught by the UI.
 */
public class ValidationException extends RuntimeException {

	/**
	 * @param message - the description of the validation errors
	 */
	public ValidationException(String message) {
		super(message);
	}

}
