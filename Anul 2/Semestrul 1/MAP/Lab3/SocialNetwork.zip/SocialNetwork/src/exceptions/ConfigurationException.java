package exceptions;

/**
 * Unchecked exception for configuration errors: the configuration file is missing,
 * or a value from it is missing or unknown (for example repository.type).
 */
public class ConfigurationException extends RuntimeException {

    /**
     * Creates the exception with a message and the original cause.
     *
     * @param message description of what went wrong
     * @param cause the original exception
     */
    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Creates the exception with a message only.
     *
     * @param message description of what went wrong
     */
    public ConfigurationException(String message) {
        super(message);
    }
}
