package exceptions;

/**
 * Unchecked exception for persistence errors (reading or writing the data source).
 * It wraps the original exception (for example IOException) as its cause.
 */
public class RepositoryException extends RuntimeException {

    /**
     * Creates the exception with a message and the original cause.
     *
     * @param message description of what went wrong
     * @param cause the original exception
     */
    public RepositoryException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Creates the exception with a message only.
     *
     * @param message description of what went wrong
     */
    public RepositoryException(String message) {
        super(message);
    }
}
