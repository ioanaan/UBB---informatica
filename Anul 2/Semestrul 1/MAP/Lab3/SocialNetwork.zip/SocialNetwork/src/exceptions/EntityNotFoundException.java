package exceptions;

/**
 * Unchecked exception thrown by the service when the requested entity does not exist
 */
public class EntityNotFoundException extends RuntimeException {

    /**
     * @param message - details about the missing entity (e.g. "user 7")
     */
    public EntityNotFoundException(String message) {
        super("Entity not found: " + message);
    }
}
