package ui;

/**
 * Contract for any user interface of the application.
 */
public interface UI {

    /**
     * Starts the user interface.
     */
    void run();
}