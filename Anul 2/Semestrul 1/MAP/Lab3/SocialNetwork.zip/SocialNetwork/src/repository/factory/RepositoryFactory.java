package repository.factory;

import domain.User;
import domain.Friendship;
import domain.Tuple;
import domain.validators.Validator;
import exceptions.ConfigurationException;
import exceptions.RepositoryException;
import repository.InMemoryRepository;
import repository.Repository;
import repository.db.UserDBRepository;
import repository.db.FriendshipDBRepository;
import repository.file.FriendshipFileRepository;
import repository.file.UserFileRepository;

import java.util.Properties;

/**
 * Simple Factory: the only place in the application that knows the concrete repository classes.
 * The type of persistence and its parameters are read from the configuration properties.
 */
public class RepositoryFactory {

    private final Properties properties;

    /**
     * Creates the factory with the application configuration.
     *
     * @param properties the properties loaded from config.properties
     */
    public RepositoryFactory(Properties properties) {
        this.properties = properties;
    }

    /**
     * Returns the value of a key that must exist in the configuration.
     *
     * @param key the name of the setting
     * @return the value, without spaces at the ends
     * @throws ConfigurationException if the key is missing or empty
     */
    private String getRequired(String key) {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank()) {
            throw new ConfigurationException("Missing value for '" + key + "' in config.properties");
        }
        return value.trim();
    }

    /**
     * Reads the persistence type from the configuration.
     *
     * @return the repository type
     * @throws ConfigurationException if the value is missing or is not MEMORY, FILE or DATABASE
     */
    public RepositoryType getRepositoryType() {
        String value = getRequired("repository.type");
        try {
            return RepositoryType.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ConfigurationException("Unknown repository type '" + value
                    + "'. Allowed values: MEMORY, FILE, DATABASE", e);
        }
    }

    /**
     * Creates the user repository for the persistence type from the configuration.
     *
     * @param validator the validator for users
     * @return the user repository
     * @throws ConfigurationException if a configuration value is missing or unknown
     * @throws RepositoryException if the data source exists but cannot be read
     */
    public Repository<Long, User> createUserRepository(Validator<User> validator) {
        switch (getRepositoryType()) {
            case MEMORY:
                return new InMemoryRepository<>(validator);
            case FILE:
                return new UserFileRepository(validator, getRequired("file.users"));
            case DATABASE:
                return new UserDBRepository(validator, getRequired("db.url"),
                        getRequired("db.user"), getRequired("db.password"));
            default:
                throw new ConfigurationException("Unsupported repository type");
        }
    }

    /**
     * Creates the friendships repository for the persistence type from the configuration.
     *
     * @param validator the validator for friendships
     * @return the friendship repository
     * @throws ConfigurationException if a configuration value is missing or unknown
     * @throws RepositoryException if the data source exists but cannot be read
     */
    public Repository<Tuple<Long, Long>, Friendship> createFriendshipRepository(Validator<Friendship> validator) {
        switch (getRepositoryType()) {
            case MEMORY:
                return new InMemoryRepository<>(validator);
            case FILE:
                return new FriendshipFileRepository(validator, getRequired("file.friendships"));
            case DATABASE:
                return new FriendshipDBRepository(validator, getRequired("db.url"),
                        getRequired("db.user"), getRequired("db.password"));
            default:
                throw new ConfigurationException("Unsupported repository type");
        }
    }

}
