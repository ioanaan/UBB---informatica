package repository.db;

import domain.User;
import repository.Repository;
import domain.validators.Validator;

/**
 * Repository for users stored in a database.
 * Skeleton only: the JDBC implementation is done in Lab 4.
 */
public class UserDBRepository implements Repository<Long, User> {

    private final Validator<User> validator;
    private final String url;
    private final String user;
    private final String password;

    private static final String NOT_IMPLEMENTED = "Database repository will be implemented in Lab 4.";

    /**
     * Creates the repository with its validator and the database connection parameters.
     *
     * @param validator the validator for users
     * @param url the database url
     * @param user the database user name
     * @param password the database password
     */
    public UserDBRepository(Validator<User> validator, String url, String user, String password) {
        this.validator = validator;
        this.url = url;
        this.user = user;
        this.password = password;
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public User findOne(Long id) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public Iterable<User> findAll() {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public User save(User entity) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public User delete(Long id) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public User update(User entity) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }
}
