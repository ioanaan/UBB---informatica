package repository.factory;

/**
 * The possible types of persistence for the repositories.
 */
public enum RepositoryType {
    MEMORY,
    FILE,
    DATABASE
}
