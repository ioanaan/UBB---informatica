package repository.file;

import domain.Friendship;
import domain.Tuple;
import domain.validators.Validator;
import exceptions.RepositoryException;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

/**
 * Text file repository for friendships; one friendship per line,
 * with the format id1;id2;date (date in ISO format, for example 2026-10-19T10:30).
 */
public class FriendshipFileRepository extends AbstractFileRepository<Tuple<Long, Long>, Friendship> {

    /**
     * @param validator - the validation strategy for friendships
     * @param fileName  - the path of the text file
     */
    public FriendshipFileRepository(Validator<Friendship> validator, String fileName) {
        super(validator, fileName);
    }

    /**
     * Converts a line of the file into a friendship.
     *
     * @param line a line with the format id1;id2;date
     * @return the friendship described by the line
     * @throws RepositoryException    if the line does not have exactly 3 fields
     * @throws NumberFormatException  if an id is not a number
     * @throws DateTimeParseException if the date is not in ISO format
     */
    @Override
    protected Friendship extractEntity(String line) {
        String[] fields = line.split(";", -1);

        if (fields.length != 3) {
            throw new RepositoryException("expected 3 fields, found " + fields.length);
        }

        Long id1 = Long.parseLong(fields[0]);
        Long id2 = Long.parseLong(fields[1]);
        LocalDateTime friendsFrom = LocalDateTime.parse(fields[2]);
        return new Friendship(id1, id2, friendsFrom);

    }

    /**
     * Converts a friendship into a line of the file.
     *
     * @param friendship the friendship to be converted
     * @return the line id1;id2;date
     */
    @Override
    protected String createEntityAsString(Friendship friendship) {
        return friendship.getUserId1() + ";" + friendship.getUserId2() + ";" + friendship.getFriendsFrom();
    }
}
