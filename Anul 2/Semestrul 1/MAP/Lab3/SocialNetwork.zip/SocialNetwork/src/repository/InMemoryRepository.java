package repository;

import domain.Entity;
import domain.validators.Validator;

import java.util.Map;
import java.util.HashMap;

/**
 * Repository that keeps the entities in memory, in a Map (id -> entity).
 * Every saved or updated entity is checked first by the validation strategy
 * received in the constructor.
 *
 * @param <ID> - type E must have an attribute of type ID
 * @param <E>  - type of entities saved in repository
 */
public class InMemoryRepository<ID, E extends Entity<ID>> implements Repository<ID, E> {
    private final Map<ID, E> entities;
    private final Validator<E> validator;

    /**
     * creates an empty repository
     * @param validator - the validation strategy used by save/update
     */
    public InMemoryRepository(Validator<E> validator) {
        this.validator = validator;
        this.entities = new HashMap<>();
    }

    @Override
    public E findOne(ID id) {
        if (id == null) {
            throw new IllegalArgumentException("id must not be null ");
        }
        return entities.get(id);

    }

    @Override
    public Iterable<E> findAll() {
        return entities.values();
    }

    @Override
    public E save(E entity) {
        if (entity == null) {
            throw new IllegalArgumentException("entity must not be null");
        }

        validator.validate(entity);

        if (entities.containsKey(entity.getId())) {
            return entity;
        }

        entities.put(entity.getId(), entity);
        return null;
    }

    @Override
    public E delete(ID id) {
        if (id == null) {
            throw new IllegalArgumentException("id must not be null ");
        }

        return entities.remove(id);
    }

    @Override
    public E update(E entity) {
        if (entity == null) {
            throw new IllegalArgumentException("entity must not be null");
        }

        validator.validate(entity);

        if (entities.containsKey(entity.getId())) {
            entities.put(entity.getId(), entity);
            return null;
        }
        return entity;

    }

}
