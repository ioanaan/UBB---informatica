package repository.db;

import domain.Friendship;
import domain.Tuple;
import domain.validators.Validator;
import repository.Repository;

public class FriendshipDBRepository implements Repository<Tuple<Long, Long>, Friendship> {

    private final Validator<Friendship> validator;
    private final String url;
    private final String user;
    private final String password;

    private static final String NOT_IMPLEMENTED = "Database repository will be implemented in Lab 4.";

    /**
     * Creates the repository with its validator and the database connection parameters.
     *
     * @param validator the validator for users
     * @param url the database url
     * @param user the database user name
     * @param password the database password
     */
    public FriendshipDBRepository(Validator<Friendship> validator, String url, String user, String password) {
        this.validator = validator;
        this.url = url;
        this.user = user;
        this.password = password;
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public Friendship findOne(Tuple<Long, Long> id) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public Iterable<Friendship> findAll() {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public Friendship save(Friendship entity) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public Friendship delete(Tuple<Long, Long> id) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }

    /**
     * @throws UnsupportedOperationException until Lab 4
     */
    @Override
    public Friendship update(Friendship entity) {
        throw new UnsupportedOperationException(NOT_IMPLEMENTED);
    }
}
