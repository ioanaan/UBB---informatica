package repository.file;

import domain.Entity;
import exceptions.ValidationException;
import domain.validators.Validator;
import repository.InMemoryRepository;
import exceptions.RepositoryException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeParseException;

/**
 * Repository that keeps the entities in memory and in a text file (one entity per line).
 * Template Method: reading and writing the file are written here once;
 * subclasses only say how a line becomes an entity and back.
 *
 * @param <ID> - type E must have an attribute of type ID
 * @param <E>  - type of entities saved in repository
 */
public abstract class AbstractFileRepository<ID, E extends Entity<ID>> extends InMemoryRepository<ID, E> {

    private final String fileName;

    /**
     * @param validator - the validation strategy for the entities
     * @param fileName  - the path of the text file
     */
    public  AbstractFileRepository(Validator<E> validator, String fileName) {
        super(validator);
        this.fileName = fileName;

        loadData();
    }

    /**
     * Converts a line of the file into an entity. Implemented by each subclass.
     *
     * @param line a line of the file
     * @return the entity described by the line
     * @throws RepositoryException if the line does not have the expected number of fields
     */
    protected abstract E extractEntity(String line);

    /**
     * Converts an entity into a line of the file. Implemented by each subclass.
     *
     * @param entity the entity to be converted
     * @return the line of text that describes the entity
     */
    protected abstract String createEntityAsString(E entity);

    /**
     * Loads the entities from the file. Corrupted or invalid lines are reported
     * (line number and reason) and ignored, so the rest of the data is still loaded.
     * If the file does not exist, the repository starts empty.
     *
     * @throws RepositoryException if the file exists but cannot be read
     */
    private void loadData(){
        try(BufferedReader reader = new BufferedReader(new FileReader(fileName, StandardCharsets.UTF_8))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if(line.isBlank())
                    continue;
                try {
                    E entity = extractEntity(line);
                    if (super.save(entity) != null)
                        System.out.println("Line " + lineNumber + " in " + fileName + " ignored: duplicate id");
                } catch (NumberFormatException | DateTimeParseException
                         | ValidationException | RepositoryException e) {
                    System.out.println("Line " + lineNumber + " in " + fileName + " ignored: " + e.getMessage());
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found. Empty repository");
        } catch (IOException e) {
            throw new RepositoryException("Error while reading the file " + fileName, e);
        }
    }

    /**
     * Rewrites the whole file with the entities currently in memory.
     *
     * @throws RepositoryException if the file cannot be written
     */
    private void writeToFile(){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, StandardCharsets.UTF_8))) {
            for (E entity : findAll()) {
                writer.write(createEntityAsString(entity));
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RepositoryException("Error while writing the file " + fileName, e);
        }
    }

    @Override
    public E save(E entity) {
        E result  = super.save(entity);
        if(result == null){
            writeToFile();
        }
        return result;
    }

    @Override
    public E delete(ID id) {
        E result = super.delete(id);
        if(result != null){
            writeToFile();
        }
        return result;
    }

    @Override
    public E update(E entity) {
        E result = super.update(entity);
        if(result == null){
            writeToFile();
        }
        return result;
    }
}
