package domain.validators;

import exceptions.ValidationException;

/**
 * Validation strategy for entities
 *
 * @param <T> - type of entity to be validated
 */

public interface Validator<T> {

    /**
     * Checks if the entity is valid
     *
     * @param entity - entity to be validated
     * @throws ValidationException if the entity is not valid
     */
    void validate(T entity);
}
