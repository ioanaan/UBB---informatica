package domain;

import java.time.LocalDateTime;

/**
 * Friendship between two users. The id is the pair of user ids,
 * always ordered with the smaller id first, so (1, 7) and (7, 1)
 * represent the same friendship.
 */
public class Friendship extends Entity<Tuple<Long, Long>> {

    private final LocalDateTime friendsFrom;

    /**
     * Creates a friendship between two users. The ids are ordered
     * with createId, so the smaller id is always first.
     *
     * @param id1 the id of one user
     * @param id2 the id of the other user
     * @param friendsFrom the date and time when the friendship was created
     */
    public Friendship(Long id1, Long id2, LocalDateTime friendsFrom) {
        setId(createId(id1, id2));
        this.friendsFrom = friendsFrom;

    }

    /**
     * Builds the id of a friendship: the pair of ids with the smaller one first.
     * If one of the ids is null, they are kept as they are (the validator will reject them).
     *
     * @param id1 id of the first user
     * @param id2 id of the second user
     * @return the normalized id
     */
    public static Tuple<Long, Long> createId(Long id1, Long id2) {
        if (id1 != null && id2 != null && id1 > id2) {
            return new Tuple<>(id2, id1);
        }
        return new Tuple<>(id1, id2);
    }

    /**
     * Returns the id of the first user (the smaller id).
     *
     * @return the id of the first user
     */
    public Long getUserId1() {
        return getId().getE1();
    }

    /**
     * Returns the id of the second user (the bigger id).
     *
     * @return the id of the second user
     */
    public Long getUserId2() {
        return getId().getE2();
    }

    /**
     * Returns the date and time when the friendship was created.
     *
     * @return the date of the friendship
     */
    public LocalDateTime getFriendsFrom() {
        return friendsFrom;
    }

    /**
     * Returns a readable description of the friendship.
     *
     * @return the text "id1 id2 since: date"
     */
    @Override
    public String toString() {
        return getUserId1() + " " + getUserId2() + " since: " + friendsFrom;
    }

}
