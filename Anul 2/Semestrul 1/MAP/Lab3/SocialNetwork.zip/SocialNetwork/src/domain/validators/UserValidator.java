package domain.validators;

import domain.User;
import exceptions.ValidationException;

/**
 * Validation strategy for User entities.
 * A user is valid if:
 * - the id is not null and positive
 * - the first name and the last name are not blank and start with an uppercase letter
 * - the email is not blank and contains '@'
 */

public class UserValidator implements Validator<User> {


    /**
     * @param entity - the user to be validated
     * @throws ValidationException if the user is null or not valid -> all the errors reported at once
     */
    @Override
    public void validate(User entity) {
        if (entity == null) {
            throw new ValidationException("User cannot be null");
        }

        String errors = "";

        if(entity.getId() == null || entity.getId() <= 0)
            errors += "Invalid ID";

        if(!isValidName(entity.getFirstName()))
            errors += "Invalid First Name ";

        if(!isValidName(entity.getLastName()))
            errors += "Invalid Last Name ";

        if(entity.getEmail() == null || entity.getEmail().isBlank() || !entity.getEmail().contains("@"))
            errors += "Invalid Email ";

        if(!errors.isEmpty())
            throw new ValidationException(errors);
    }

    /**
     * @param name - name to be checked
     * @return true if name not null, blank and starts with an uppercase letter
     */
    private boolean isValidName(String name) {
        return name != null && !name.isBlank() && Character.isUpperCase(name.charAt(0));
    }
}
