package domain;

import java.util.Objects;

/**
 * Base class for all entities that have an identifier
 *
 * @param <ID> - type of the entity identifier
 */
public class Entity<ID> {

    private ID id;

    /**
     * Returns the identifier of the entity.
     *
     * @return the id of the entity
     */
    public ID getId() {
        return id;
    }

    /**
     * Sets the identifier of the entity.
     *
     * @param id the new id
     */
    public void setId(ID id) {
        this.id = id;
    }

    /**
     * Two entities are equal if they have the same id.
     *
     * @param o the object to compare with
     * @return true if o is an entity with the same id, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Entity<?>)) return false;

        Entity<?> entity = (Entity<?>) o;
        return Objects.equals(id, entity.id);

    }

    /**
     * Returns a hash code based on the id, consistent with equals.
     *
     * @return the hash code of the entity
     */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}