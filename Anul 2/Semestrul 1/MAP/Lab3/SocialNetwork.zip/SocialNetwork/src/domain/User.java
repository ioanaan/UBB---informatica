package domain;

/**
 * User of the social network, identified by an id of type Long
 */
public class User extends Entity<Long> {

    private String firstName;
    private String lastName;
    private String email;

    /**
     * Creates a user. The id is set separately, with setId.
     *
     * @param firstName the first name of the user
     * @param lastName  the last name of the user
     * @param email     the email address of the user
     */
    public User(String firstName, String lastName,  String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    /**
     * Returns the first name of the user.
     *
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name of the user.
     *
     * @param firstName the new first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Returns the last name of the user.
     *
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the last name of the user.
     *
     * @param lastName the new last name
     */
    public void setLastName(String lastName) {
        this.lastName =lastName;
    }

    /**
     * Returns the email address of the user.
     *
     * @return the email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email the new email address
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns a readable description of the user.
     *
     * @return the text "id, firstName, lastName, (email)"
     */
    @Override
    public String toString() {
        return getId() + ", " + firstName + ", " + lastName +  ", " + "(" + email + ")";
    }
}
