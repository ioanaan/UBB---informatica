package domain;

import java.util.Objects;

/**
 * Immutable pair of two values
 *
 * @param <E1> - type of the first value
 * @param <E2> - type of the second value
 */
public class Tuple<E1, E2> {

    private final E1 e1;
    private final E2 e2;

    /**
     * Creates a pair with the two given values.
     *
     * @param e1 the first value
     * @param e2 the second value
     */
    public Tuple(E1 e1, E2 e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    /**
     * Returns the first value of the pair.
     *
     * @return the first value
     */
    public E1 getE1() {
        return e1;
    }

    /**
     * Returns the second value of the pair.
     *
     * @return the second value
     */
    public E2 getE2() {
        return e2;
    }

    /**
     * Two tuples are equal if their values are equal, in the same order.
     *
     * @param o the object to compare with
     * @return true if o is a tuple with equal values, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if(!(o instanceof Tuple<?, ?>)) return false;

        Tuple<?, ?> tuple = (Tuple<?, ?>) o;
        return Objects.equals(e1, tuple.e1) && Objects.equals(e2, tuple.e2);

    }

    /**
     * Returns a hash code based on both values, consistent with equals.
     *
     * @return the hash code of the tuple
     */
    @Override
    public int hashCode() {
        return Objects.hash(e1, e2);
    }
}
