import domain.Friendship;
import domain.Tuple;
import domain.User;
import domain.validators.FriendshipValidator;
import domain.validators.UserValidator;
import exceptions.ConfigurationException;
import exceptions.RepositoryException;
import repository.Repository;
import repository.factory.RepositoryFactory;
import service.CommunityService;
import service.FriendshipService;
import service.UserService;
import ui.ConsoleUI;
import ui.UI;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Entry point of the application. Loads the configuration, creates the repositories
 * through the factory, wires the services and starts the UI.
 */
public class Main {

    /**
     * Starts the application.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        try {
            // 1. configuration
            Properties properties = loadProperties("config.properties");

            // 2. factory
            RepositoryFactory factory = new RepositoryFactory(properties);
            System.out.println("Persistence type: " + factory.getRepositoryType());

            // 3. repositories (only through the factory, only the interface is visible here)
            Repository<Long, User> userRepository =
                    factory.createUserRepository(new UserValidator());
            Repository<Tuple<Long, Long>, Friendship> friendshipRepository =
                    factory.createFriendshipRepository(new FriendshipValidator());

            // 4. services and UI (same as before)
            UserService userService = new UserService(userRepository, friendshipRepository);
            FriendshipService friendshipService = new FriendshipService(friendshipRepository, userRepository);
            CommunityService communityService = new CommunityService(userRepository, friendshipRepository);

            System.out.println("User repository: " + userRepository.getClass().getSimpleName());
            System.out.println("Friendship repository: " + friendshipRepository.getClass().getSimpleName());

            UI ui = new ConsoleUI(userService, friendshipService, communityService);
            ui.run();
        } catch (ConfigurationException e) {
            System.out.println("Configuration error: " + e.getMessage());
        } catch (RepositoryException e) {
            System.out.println("Data error: " + e.getMessage());
        }
    }

    /**
     * Loads a properties file from the classpath (the resources folder).
     *
     * @param resource the name of the file
     * @return the loaded properties
     * @throws ConfigurationException if the file is missing or cannot be read
     */
    private static Properties loadProperties(String resource) {
        Properties properties = new Properties();
        try (InputStream input = Main.class.getClassLoader().getResourceAsStream(resource)) {
            if (input == null) {
                throw new ConfigurationException("Configuration file " + resource + " not found");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new ConfigurationException("Error while reading the configuration file " + resource, e);
        }
        return properties;
    }
}