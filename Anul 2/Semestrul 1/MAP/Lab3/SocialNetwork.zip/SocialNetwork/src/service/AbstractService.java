package service;

import domain.Entity;
import repository.Repository;

/**
 * Base class for the services that manage one type of entity.
 * Keeps the repository of that entity and the operations common to all services.
 *
 * @param <ID> - type E must have an attribute of type ID
 * @param <E> - type of the entities managed by the service
 */
public abstract class AbstractService<ID, E extends Entity<ID>> {

    protected final Repository<ID, E> repository;

    /**
     * @param repository - the repository of the managed entities
     */
    protected AbstractService(Repository<ID, E> repository) {
        this.repository = repository;
    }

    /**
     * @return all the entities managed by this service
     */
    public Iterable<E> getAll() {
        return repository.findAll();
    }
}